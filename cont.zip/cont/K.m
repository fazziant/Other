function [Kup,Kyp,Kuf,Kyf]=K(U,Y,tini,tf)
%Build block-Hankel matrix for data-driven prediction and control
% output
% Kup, Kyp: past input and output rows Hankel matrix
% Kuf, Kyf: future input and output rows Hankel matrix
% input
% U, Y: input and output trajectories
% tini: and tf: lengths initial condition and prediction
% N: number of basis function

% liftFun = @(xx)( [xx, sin(xx)] );
% Ulift = liftFun(U);
% Ylift = liftFun(Y);
Ulift = [U];
Ylift = [Y, sin(Y)];
nc=size(Ylift,1)-tini-tf;

for i=1:1
    Hu(:,:,i) =blkhank(Ulift(:,i),tini+tf,nc);
    Hup(:,:,i)=Hu(1:tini,:,i);
    Huf(:,:,i)=Hu(tini+1:tini+tf,:,i);
end
for i=1:2
    Hy(:,:,i) =blkhank(Ylift(:,i),tini+tf,nc);
    Hyp(:,:,i)=Hy(1:tini,:,i);
    Hyf(:,:,i)=Hy(tini+1:tini+tf,:,i);
end

Kup=[]; Kuf=[]; 
Kyp=[]; Kyf=[];
for j=1:1
    Kup=[Kup;Hup(:,:,j)];
    Kuf=[Kuf;Huf(:,:,j)];
end
for j=1:2
    Kyp=[Kyp;Hyp(:,:,j)];
    Kyf=[Kyf;Hyf(:,:,j)];
end
