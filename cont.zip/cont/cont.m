% check controllability
%k=4, nl=2 is the only realization returning a common root (up to the 2nd
%decimal place)

  clear
load('pcnl2-03062024.mat')
%set the data pair
   k=4; %realization between 1 and 100
nl=2; %noise level between 1 and 3

% set the data pair
ud=un(:,k);
yd=Zn(:,k,nl);
T=length(yr)-N;
nd=length(ud);
Ud=ud(1:nd-tini);
Yd=yd(1:nd-tini);
Uini=[u(nd-tini+1:nd)];
Yini=[Z(nd-tini+1:nd)];

%%% basis functions
[Kup,Kyp,Kuf,Kyf]=K(Ud,Yd,tini,1);

%approximation by LQ decomposition
[Q, L]=qr([Kup;Kyp;Kuf;Kyf(1,:)]',0);
L=L';
Q=Q';
Kyf(1,:)=L(end,1:end-tini)*Q(1:end-tini,:);

%estimated data matrix
B=[Kup;Kuf;Kyp;Kyf];
[U,S,V]=svd(B);

P=U([8,5,4],end);
Q=U([2,1],end);
roots(P)
roots(Q)


% addpath('/Users/antoniofazzi/Library/CloudStorage/Dropbox/Work/myfiles/polyx/')
% Q=[U([4,5,8],end)';U([6,7,9],end)']
% Q0=diag([Q(:,1)]);
% Q1=diag([Q(:,2)]);
% Q2=diag([Q(:,3)]);
% Qp=ppck([Q0,Q1,Q2],2)
% rP=roots(U(2:-1:1,end))
% pval(Qp,rP)